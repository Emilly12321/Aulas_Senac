// index.js
require('dotenv').config();
const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.json('Hello World!');
})

app.post('/send-email-contato', async (req, res) => {
    const { nome, email, mensagem } = req.body;
    const transporter = nodemailer.createTransport({
        host: process.env.EMAIL_HOST,
        port: process.env.EMAIL_PORT,
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });
    const mailOptions = {
        from: process.env.EMAIL_REMETENTE,
        to: email,
        subject: 'Submissão via tela de contato',
        text: `Nome: ${nome}\nEmail: ${email}\nMensagem: ${mensagem}`,
        html: `<b style="color:green">Nome</b>: ${nome}<br> <b>Email</b>: ${email} <br> <b>Mensagem</b>: ${mensagem}`
    };

    try {
        await transporter.sendMail(mailOptions, (error, info) => {
            if (error) { return console.error(error); }
        });
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});


app.post('/send-email-confirmacao', async (req, res) => {
    // mandar um número aleatório de 6 digitos, para confirmar o cadastro
});

app.post('/send-email-boas-vindas', async (req, res) => {
    // mandar uma mensagem de boas vindas ao sistema ao novo usuário do 
});

app.post('/send-email-recuperar-senha', async (req, res) => {
    // envia uma senha aleatório de 8 caracteres (letras e números, simbolos) e uma mensagem dizendo que ela deve ser alterada após o primeiro login
});

app.post("/send-email-senha-modificada", async (req,res) =>{
    //enviar um email falando que a senha foi alterada com sucesso.
});




const port = 5000;
app.listen(port, () => {
    console.log(`O servidor está rodando na porta http://localhost:${port}`);
});